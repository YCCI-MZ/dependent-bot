import urllib.request as req
from urllib import error
import time
import socket
import json
from requests import request

from crawler.tools import get_random_lib_key, get_random_user_agent


# 根据包名从libraries.io获取包的相关信息
def crawl_pkg_info(pkg_name):
    # 构建请求
    pkg_name = pkg_name.strip()
    api_key = get_random_lib_key()
    random_agent = get_random_user_agent()
    url_version = "https://libraries.io/api/maven/%s?api_key=%s" % (pkg_name, api_key)
    # print(url_version)
    headers = {'User-Agent': random_agent}
    r = req.Request(url_version, headers=headers)
    # 调用API
    try:
        response = req.urlopen(r)
    except error.HTTPError as e:
        if e.code == 429 or e.code == 502:   # 访问频繁被拒绝
            print("wait 30s for error %s while crawling pkg:%s" % (e.code, pkg_name))
            time.sleep(30)
            ret = crawl_pkg_info(pkg_name)
            return ret
        else:   # 获取包信息失败
            print(e.code)
            print("HTTP error no pkg: %s" % pkg_name)
            return {}
    except socket.error as e:
        time.sleep(10)
        print("sleep now")
        return crawl_pkg_info(pkg_name)
    # 解析返回值
    response_dict = json.load(response)
    all_version = []
    for ver in response_dict['versions']:
        version_num = ver['number']  # 获取具体的版本号
        all_version.append(version_num)
    pkg = {
        "name": pkg_name,
        "latest_version": response_dict['latest_release_number'],
        "repository_url": response_dict['repository_url'],
        "homepage": response_dict['homepage'],
        "info": response_dict['description'],
        "all_version": all_version
    }
    return pkg


# 根据包id从sonatype获取包的漏洞情况
def crawl_pkg_cve(pkg_id):
    # 构建请求
    url = f"https://ossindex.sonatype.org/api/v3/component-report"
    print(url + " [" + pkg_id + ']')
    header = {
        "Content-Type": "application/json",
        'username': "1609450657@qq.com",
        'password': "f10e87fe18925b2fe4fedbcbe0225aa06c972aa8",
    }
    pkg_group_id = pkg_id.split(':')[0]
    pkg_artifact_id = pkg_id.split(':')[1].split('@')[-2]
    pkg_version = pkg_id.split('@')[-1]
    payload = {
        "coordinates": [
            f"pkg:maven/{pkg_group_id}/{pkg_artifact_id}@{pkg_version}"
        ]
    }
    # 调用API
    try:
        response = request(method="POST", url=url, json=payload, headers=header)
        if response.status_code == 200:
            pkg_dict = json.loads(response.text)
        else:
            # 访问频繁被拒绝
            print(f"wait 30s for error while crawling cve of pkg:{pkg_id}")
            time.sleep(30)
            return crawl_pkg_cve(pkg_id)
    except Exception as e:
        raise e
    # 解析返回值
    cve_list = pkg_dict[0]["vulnerabilities"]
    return cve_list


def crawl_test():
    print(crawl_pkg_cve("junit:junit@4.13"))


if __name__ == '__main__':
    crawl_test()


