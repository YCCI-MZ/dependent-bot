import neo4j_db
import copy

db = neo4j_db.DataBase()
path = []
all_path = []


# node_id: 用户调用的第三方包函数
# target: 有漏洞的函数列表
def dfs_upstream(node_id, target):
    # 向上查找，防止递归次数太高
    if len(path) > 10:
        return
    # 获取 node_id 的上游节点
    index_method_list = db.get_inner_upstream_for_method(node_id)
    if index_method_list is None:
        index_method_list = []
    # 由于下一节点可能是包内也可能是包外，所以边界节点也要考虑自己
    index_method_list.append(node_id)
    path.append(node_id)

    for index_method in index_method_list:
        # 判断是否是除自己以外的索引节点
        isIndex = True
        if index_method not in path:
            path.append(index_method)
        else:
            isIndex = False

        if index_method in target:
            print(path)
            tmp = copy.deepcopy(path)
            all_path.append(tmp)

        else:
            out_call_method_list = db.match_out_call_by_method(index_method)
            for out_call_method in out_call_method_list:
                # 传播到了目标方法列表
                if out_call_method in target:
                    path.append(out_call_method)
                    print(path)
                    tmp = copy.deepcopy(path)
                    all_path.append(tmp)
                    path.pop()
                else:
                    dfs_upstream(out_call_method, target)
        if isIndex:
            path.pop()
    path.pop()


def path_to_string(path_list):
    string_path_list = []
    for single_path in path_list:
        string_path = ""
        for i in range(len(single_path)):
            node = db.match_node_by_id(single_path[i])
            string_path += node['id']
            if i < len(single_path) - 1:
                string_path += "   --->   "
        string_path_list.append(string_path)
    all_path.clear()
    return string_path_list


def query_indexed_path(dep_list):
    # org.codehaus.plexus:plexus-archiver:3.5@org.codehaus.plexus.archiver.AbstractUnArchiver:extractFile(java.io.File,java.io.File,java.io.InputStream,java.lang.String,java.util.Date,boolean,java.lang.Integer,java.lang.String)
    vul_method = [176]
    for node_id in dep_list:
        dfs_upstream(node_id, vul_method)
    return path_to_string(all_path)
