import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, curPath)
from Resolve import Resolve
from path import query_indexed_path

r = Resolve()


def handle_cg_query(user_name, repo_name):
    group = user_name + "." + repo_name + ".test"
    artifact = "vul"
    version = "1.0"
    dep_list = r.solve_pkg_user(group, artifact, version, includedeps=False, depdep=False)
    print(dep_list)
    string_path = query_indexed_path(dep_list)
    print(string_path)
    return string_path


# handle_cg_query()
