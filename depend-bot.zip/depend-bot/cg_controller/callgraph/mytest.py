import re

# 定义一个正则表达式模式
alpthaPattern = r"[0-9a-zA-Z\_\$]"
noOroneToken =  alpthaPattern + "*"
oneToken =  alpthaPattern + "+"

classPattern = r"(" +  oneToken + "\.)*" +  oneToken

class_class_pattern = r"^C\:" + "(" +  classPattern + ")" + " " + "(" +  classPattern + ")" + "$"


# 要匹配的字符串
string = "C:com.github.alexcojocaru.mojo.elasticsearch.v2.ForkedElasticsearchProcessDestroyer java.lang.Runtime"

# 使用 re.match() 函数进行匹配
match_object = re.match(class_class_pattern, string)

# 判断是否匹配成功
if match_object:
    print("Match found:", match_object.group(3))
else:
    print("No match")
