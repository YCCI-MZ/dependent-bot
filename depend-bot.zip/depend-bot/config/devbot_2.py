import os

from config.config import CONFIG_DIR

host = "https://www.gitlink.org.cn"

bot = {
    "bot_id": 10034,
    "client_id": "28d4a926229b49abaa91755c66f59275",
    "client_secret": "3SOzKjjajqq4Me-Cpb-OYe645quynELFx8IxsuQsCd0",
    "private_key": os.path.join(CONFIG_DIR, "private_key_10034.txt")
}
