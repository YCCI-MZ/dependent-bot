import os

from config.config import CONFIG_DIR

host = "https://testforgeplus.trustie.net"

bot = {
    "bot_id": 860,
    "client_id": "ef77c30c49434203a7030f3aca47ca92",
    "client_secret": "BPNrP_cAIbv62Y6p_qnnFrI8e2k0iGIvWNpk7WgWtlM",
    "private_key": os.path.join(CONFIG_DIR, "private_key_860.txt")
}
