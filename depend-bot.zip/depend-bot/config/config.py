import os

# HOST = "https://testforgeplus.trustie.net"
HOST = "https://gitlink.org.cn/"

ROOT_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

CONFIG_DIR = os.path.join(ROOT_DIR, "config")

