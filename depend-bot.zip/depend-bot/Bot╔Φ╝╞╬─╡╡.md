# Bot设计文档

## Bot系统架构设计

![Bot系统架构-导出](https://s2.loli.net/2023/09/13/XEARmgs35GOkqvb.png)

## Bot数据结构设计

![mybot数据库设计-导出](https://s2.loli.net/2023/09/15/bA5xhpPHUmvXMjI.png)

## Bot功能模块设计

![功能模块图-导出](https://s2.loli.net/2023/09/13/W1NX3JInmqpglYi.png)

代码重构多数据源

lib.io +, why , weakness,

C/C++语言包管理器
Conan
数量类型

河图如何对指定项目分析（特别是细粒度）

开源课程其他生态扩充

buaa-act-sig
