import json
from flask import Flask, render_template, request

from jobs.scheduler import scheduler
from jobs.bot_execute import do_job

from controller.get_access_token import get_access_token
from controller.get_project_dep import get_project_dependency, download_files
from controller.cmp_dependency import cmp_dep
from controller.create_issue import create_issue_dep_update, create_issue_vul_report, create_issue_cg_vul_report
from controller.get_pkg_vul import get_pkg_vul
from controller.build_graph import build_dep_graph, build_vul_graph
from controller.send_email import send_dep_update_report
from cg_controller.callgraph.handler import handle_cg_query


app = Flask(__name__)


@app.route("/")
def root():
    return render_template('index.html')


@app.route('/webhook', methods=['GET', 'POST'])
def webhook():
    print(request.url)
    # 获取commit信息
    try:
        request_data = json.loads(request.data)
        bot_installer_id = request.args.get("installer_id")
        for commit in request_data["commits"]:
            # 新建maven项目的情况
            if "pom.xml" in commit["added"] or "pom.xml" in commit["modified"]:
                # ref = request_data["ref"]
                user_name = request_data["repository"]["owner"]["login"]
                user_email = request_data["repository"]["owner"]["email"]
                repo_name = request_data["repository"]["name"]
                # 获取access_token供API调用
                access_token = get_access_token(bot_installer_id)
                # 获取依赖        
                dependencies = get_project_dependency(user_name, repo_name)
                download_files(user_name, repo_name)
                vul_string_paths = handle_cg_query(user_name, repo_name)
                # 提交风险提醒的issue
                if len(vul_string_paths) != 0:
                    create_issue_cg_vul_report(user_name, repo_name, vul_string_paths, access_token)

                # 依赖更新检测
                update_list = cmp_dep(dependencies)
                print("%s dependencies are not latest" % len(update_list))
                # 提交更新提醒的issue
                # if len(update_list) != 0:
                #     create_issue_dep_update(user_name, repo_name, update_list, access_token)
                    # send_dep_update_report(user_email, repo_name, update_list)

                # 构建或更新图
                # build_dep_graph(user_name, repo_name, dependencies, bot_installer_id)

                # 漏洞识别
                # pkg_vul_list = get_pkg_vul(dependencies)
                # # 漏洞存储
                # build_vul_graph(pkg_vul_list)
                # 漏洞提醒
                # if len(pkg_vul_list) != 0:
                #     create_issue_vul_report(user_name, repo_name, pkg_vul_list, access_token)

            else:
                pass
    except Exception as e:
        raise e
    return ""


def run_bot():
    # 创建定时任务(如果未创建)
    job = scheduler.get_job("do_job")
    if not job:
        scheduler.add_job(func=do_job, trigger="interval", id="do_job", seconds=5)
    # 启动定时任务
    scheduler.init_app(app)
    scheduler.start()
    # 启动flask应用
    app.run(debug=True, host='0.0.0.0', port=5000)


if __name__ == '__main__':
    run_bot()


