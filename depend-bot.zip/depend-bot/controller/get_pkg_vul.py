from crawler.crawl import crawl_pkg_cve


def get_pkg_vul(dependencies):
    pkg_vul_list = []
    # 获取各依赖项的漏洞情况
    for dep in dependencies:
        pkg_id = dep["group_id"] + ':' + dep["artifact_id"] + '@' + dep["version"]
        cve_list = crawl_pkg_cve(pkg_id)
        for cve in cve_list:
            # cve格式化
            cve = {
                "ID": cve["id"],
                "description": cve["description"],
                "cwe": cve["cwe"],
                "cvss_score": cve["cvssScore"],
                "reference": cve["reference"]
            }
            pkg_vul_dict = {
                "pkg": pkg_id,
                "vul": cve,
            }
            pkg_vul_list.append(pkg_vul_dict)
    return pkg_vul_list
