from database.graph_db import DataBase
from database.entity import Repository
from crawler.crawl import crawl_pkg_info


def build_dep_graph(user_name, repo_name, dependencies, bot_installer_id):
    db = DataBase()
    # 构建安装bot的仓库结点
    repo = Repository(user_name, repo_name, bot_installer_id)
    repo_dict = repo.get_dict()
    repo_node = db.add_repository(repo_dict)
    relation_list = db.query_relations_by_node_start(repo_node, "depend_on")
    # 记录旧依赖是否在此次更新后依然存在
    old_dependency_dict = {}
    for r in relation_list:
        old_dependency_dict[r.end_node['name']] = 0
    # 构建包结点及依赖关系
    for dep in dependencies:
        name = dep['group_id'] + ':' + dep['artifact_id']
        if old_dependency_dict.get(name) is not None:
            old_dependency_dict[name] = 1
        cur_version = dep['version']
        # 对于每个依赖的包构建其全部版本信息
        pkg = crawl_pkg_info(name)
        db.add_package(pkg)
        # 添加仓库和包结点的依赖关系
        pkg_id = name + "@" + cur_version
        cur_node = db.match_pkg_by_id(pkg_id)
        db.update_repo_pkg_relation(repo_node, cur_node)
    # 更新后删除多余依赖
    count = 0
    for pkg_name in old_dependency_dict:
        # 已经不再使用此依赖
        if old_dependency_dict[pkg_name] == 0:
            db.run(f"MATCH (m)-[r:depend_on]->(n) where m.url='{repo_node['url']}' and n.name='{pkg_name}' delete r")
            count += 1
    if count > 0:
        print("delete unused %s dependencies" % count)
    print("build and update new graph done!")


def build_vul_graph(pkg_vul_list):
    db = DataBase()
    for pkg_vul_mapping in pkg_vul_list:
        pkg_id = pkg_vul_mapping["pkg"]    # 图中已存在
        vul_dict = pkg_vul_mapping["vul"]  # 图中不存在
        # 构建结点
        vul_node = db.add_vul(vul_dict)
        # 构建关系
        pkg_node = db.match_pkg_by_id(pkg_id)
        db.add_vul_pkg_relation(vul_node, pkg_node)


