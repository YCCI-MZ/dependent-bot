from common.generate_jwt import generate_jwt_token
from config.devbot_2 import bot, host
from base_api.bot_api import BotApi


def get_access_token(bot_installer_id):
    jwt_token = generate_jwt_token(bot)
    bot_api = BotApi(host)
    access_token = bot_api.get_access_tokens(bot_installer_id, jwt_token)
    return access_token
