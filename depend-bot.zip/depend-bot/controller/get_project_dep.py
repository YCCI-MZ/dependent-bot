from base_api.project_api import ProjectApi
from config.config import HOST
from common.xml_parser import XmlParser
import xml.etree.ElementTree as ET
import os


def get_project_dependency(user_name, repo_name):
    project_api = ProjectApi(HOST)
    # 获取pom.xml
    pom = project_api.get_repo_file(user_name, repo_name, "pom.xml")
    pom_content = pom["entries"]["content"]
    # 解析pom.xml
    xml_parser = XmlParser(pom_content)
    dependencies = xml_parser.get_dependencies()
    return dependencies

def download_files(user_name, repo_name):
    jarPath = "./data/jars/" + user_name + "/" + repo_name + "/test/vul/1.0"
    jarName = user_name + "." + repo_name + ".test--vul--1.0.jar"
    if not os.path.exists(jarPath):
        print(1)
        os.makedirs(jarPath)
    print(jarPath)
    print(jarName)
    project_api = ProjectApi(HOST)
    project_api.download_file_from_gitlink(user_name, repo_name, "pom.xml", jarPath + "/" + "pom.xml")
    project_api.download_file_from_gitlink(user_name, repo_name, "test--vul--1.0.jar", jarPath + "/" + jarName)
    print("download files done!")

def get_dependency_test():
    tree = ET.parse("../pom.xml")
    root = tree.getroot()
    xml_str = ET.tostring(root)
    xml_parser = XmlParser(xml_str)
    dependencies = xml_parser.get_dependencies()
    print(dependencies)
    return dependencies


