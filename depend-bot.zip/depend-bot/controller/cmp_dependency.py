from crawler.crawl import crawl_pkg_info


def cmp_dep(dependencies):
    update_list = []
    # 查询依赖版本是否需要更新
    for dep in dependencies:
        name = dep['group_id'] + ':' + dep['artifact_id']
        cur_version = dep['version']
        pkg = crawl_pkg_info(name)
        if pkg == {}:
            continue
        else:
            latest_version = pkg['latest_version']
            repository_url = pkg['repository_url']
            # 当前为最新版本
            if cur_version == '' or cur_version == latest_version:
                # print("%s@%s has been the latest" % (name, cur_version))
                continue
            # 依赖项非最新版本
            else:
                # print("%s is not latest, suggest update it from %s to %s, check it in detail on %s"
                # % (name, cur_version, latest_version, repository_url))
                update_list.append({
                    "name": name,
                    "current_version": cur_version,
                    "latest_version": latest_version,
                    "repository_url": repository_url,
                })
    # 返回待更新的依赖列表
    return update_list


# def cmp_dep(dependencies):
#     dep_detail = []
#     for dep in dependencies:
#         name = dep['group_id'] + ':' + dep['artifact_id']
#         pkg = crawl_pkg_info(name)
#         if pkg == {}:
#             continue
#         else:
#             dep['latest_version'] = pkg['latest_version']
#             dep['repository_url'] = pkg['repository_url']
#             dep_detail.append(dep)
#     return dep_detail

