import yagmail


def send_dep_update_report(address, repo_name, update_list):
    # 连接服务器
    # 用户名、授权码、服务器地址
    yag_server = yagmail.SMTP(user='gy13278791575@163.com', password='NMAZALLZBVGVMJAX', host='smtp.163.com')

    # 发送对象列表
    email_to = [address, ]
    email_title = 'GitLink Repository Dependencies Update Warnning'
    email_content = "The latest version of some dependent software packages for your project %s already exists. " \
                        "The update suggestions are as follows:\n\n" % repo_name
    for update_pkg in update_list:
        msg = f"{update_pkg['name']} is not latest, suggest update it from " \
              f"{update_pkg['current_version']} to {update_pkg['latest_version']}, " \
              f"check it in detail on {update_pkg['repository_url']}"
        email_content += "- " + msg + '\n'
    # 附件列表
    email_attachments = []

    # 发送邮件
    yag_server.send(email_to, email_title, email_content, email_attachments)
