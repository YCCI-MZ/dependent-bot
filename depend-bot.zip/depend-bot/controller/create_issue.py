from config.config import HOST
from base_api.repository_api import RepositoryApi

from base_api.bot_api import BotApi
from common.generate_jwt import generate_jwt_token
from config.devbot_2 import bot


def create_issue_dep_update(user_name, repo_name, update_list, access_token):
    # 构建issue_body
    issue_description = "The latest version of some dependent software packages for the project already exists. " \
                        "The update suggestions are as follows:\n\n"
    for update_pkg in update_list:
        msg = f"{update_pkg['name']} is not latest, suggest update it from " \
              f"{update_pkg['current_version']} to {update_pkg['latest_version']}, " \
              f"check it in detail on {update_pkg['repository_url']}"
        issue_description += "- " + msg + '\n'
    payload = {
        "description": issue_description,
        "due_date": "",
        "priority_id": "2",
        "receivers_login": [],
        "start_date": "",
        "status_id": "1",
        "subject": "Dependency Update Reminder -- 依赖更新提醒",
    }

    # 调用API提issue
    repo_api = RepositoryApi(HOST, user_name, repo_name, access_token)
    response = repo_api.create_issue(payload)
    # print(response)


def create_issue_vul_report(user_name, repo_name, pkg_vul_list, access_token):
    # 构建issue_body
    issue_description = "The software package that the project depends on may have vulnerabilities!\n"
    pre_pkg = ""
    for pkg_vul_mapping in pkg_vul_list:       # 统计并汇报每一个包的漏洞
        pkg = pkg_vul_mapping["pkg"]
        vul_cve_id = pkg_vul_mapping["vul"]["ID"]
        reference = pkg_vul_mapping["vul"]["reference"].split('?')[0]
        if pkg != pre_pkg:
            msg = f"- {pkg} may have vulnerabilities as follows:\n" + f"[{vul_cve_id}]\tcheck it in detail on: {reference}\n"
        else:
            msg = f"[{vul_cve_id}]\tcheck it in detail on: {reference}\n"
        issue_description += msg
        pre_pkg = pkg
    payload = {
        "description": issue_description,
        "due_date": "",
        "priority_id": "2",
        "receivers_login": [],
        "start_date": "",
        "status_id": "1",
        "subject": "Dependency Vulnerability Report -- 依赖项漏洞报告",
    }

    # 调用API提issue
    repo_api = RepositoryApi(HOST, user_name, repo_name, access_token)
    response = repo_api.create_issue(payload)
    print(response)

def create_issue_cg_vul_report(user_name, repo_name, path_list, access_token):
        # 构建issue_body
    issue_description = "There are some vulnerabilities in your dependencies. Please change your code according to the vul propragation path. " \
                        "The paths including vulnerabilities are as follows:\n\n"
    for vul_path in path_list:
        issue_description += "    " + vul_path + '\n'
    payload = {
        "description": issue_description,
        "due_date": "",
        "priority_id": "2",
        "receivers_login": [],
        "start_date": "",
        "status_id": "1",
        "subject": "Dependency Risk Reminder -- 依赖风险提醒",
    }

    # 调用API提issue
    repo_api = RepositoryApi(HOST, user_name, repo_name, access_token)
    response = repo_api.create_issue(payload)
    # print(response)
