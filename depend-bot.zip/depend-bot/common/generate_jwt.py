"""
pypi地址：https://pypi.org/project/jwt/
# JWT 签名算法
JWT 最常见的几种签名算法(JWA)：HS256(HMAC-SHA256) 、RS256(RSA-SHA256) 还有 ES256(ECDSA-SHA256)。
## HS256
HS256 使用同一个「secret_key」进行签名与验证（对称加密）。一旦 secret_key 泄漏，就毫无安全性可言了。
因此 HS256 只适合集中式认证，签名和验证都必须由可信方进行。
## RS256
RS256 是使用 RSA 私钥进行签名，使用 RSA 公钥进行验证。公钥
## ES256
ES256 和 RS256 一样，都使用私钥签名，公钥验证。算法速度上差距也不大，但是它的签名长度相对短很多（省流量），并且算法强度和 RS256 差不多。
"""

import jwt  # 安装：pip install jwt
from jwt import jwk_from_pem
from jwt.utils import get_int_from_datetime
from datetime import datetime, timezone, timedelta


def generate_jwt_token(bot, alg="RS256"):
    """
    生成jwt_token
    :param bot: bot的信息，包括bot_id以及bot私钥保存的文件的绝对路径
    :param alg: 算法类型
    :return: 返回jwt_token
    """
    try:
        with open(bot.get("private_key"), "rb") as fh:
            # 返回是一个jwt对象，如下：<jwt.jwk.RSAJWK object at 0x00000293FDA1FFA0>
            signing_key = jwk_from_pem(fh.read())

        payload = {
            # Issued at time
            'iat': get_int_from_datetime(datetime.now(timezone.utc)),
            # JWT expiration time (10 minutes maximum)
            'exp': get_int_from_datetime(datetime.now(timezone.utc) + timedelta(hours=1)),
            'iss': bot.get('bot_id')  # bot的id
        }
        jwt_instance = jwt.JWT()
        return jwt_instance.encode(payload=payload, alg=alg, key=signing_key)
    except Exception as e:
        raise e
