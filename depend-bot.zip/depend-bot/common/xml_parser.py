import xml.etree.ElementTree as ET


class XmlParser:

    def __init__(self, xml_content):
        self.xml_content = xml_content

    def get_dependencies(self):
        dependency_list = []
        root = ET.fromstring(self.xml_content)
        for child in root:
            tag_name = child.tag.split("}")[-1]
            if tag_name == "dependencies":
                for dependency in child:
                    # 提取依赖
                    project = {
                        "group_id": "",
                        "artifact_id": "",
                        "version": ""
                    }
                    for item in dependency:
                        if item.tag.split("}")[-1] == "groupId":
                            project["group_id"] = item.text
                        if item.tag.split("}")[-1] == "artifactId":
                            project["artifact_id"] = item.text
                        if item.tag.split("}")[-1] == "version":
                            project["version"] = item.text
                    # 依赖需要保证版本号不为空
                    if project["version"] != "":
                        dependency_list.append(project)
        return dependency_list
