import json
from requests import request


class RepositoryApi:
    def __init__(self, host, user_name, repo_name, access_token=None):
        self.host = host
        self.user_name = user_name
        self.repo_name = repo_name
        self.headers = {
            "Content-Type": "application/json",
        }
        if access_token:
            self.headers["Authorization"] = f"Bearer {access_token}"

    def create_issue(self, payload):
        try:
            url = f"{self.host}/api/v1/{self.user_name}/{self.repo_name}/issues"
            print(url)
            response = request(method="POST", url=url, json=payload, headers=self.headers)
            if response.status_code == 200:
                return json.loads(response.text)
        except Exception as e:
            raise e
