import json

from requests import request


class RepositoryApi:
    def __init__(self, host, access_token=None):
        self.host = host
        self.headers = {
            "Content-Type": "application/json",
        }
        if access_token:
            self.headers["Authorization"] = f"Bearer {access_token}"

    def get_user_info(self):
        try:
            url = f"{self.host}/api/users/me.json"
            response = request(method="GET", url=url, headers=self.headers)
            if response.status_code == 200:
                return response.json()
            else:
                return response.text
        except Exception as e:
            raise e
