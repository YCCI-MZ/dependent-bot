from requests import request
import json


class BotApi:

    def __init__(self, host):
        """
        :param host: 平台域名
        """
        self.host = host

    def get_access_tokens(self, bot_installer_id, jwt_token):
        """
        申请授权Token
        :param bot_installer_id: bot安装到某个仓库的安装id bot_install.installer_id=安装用户的id：user_id
        :param jwt_token: jwt_token
        :return: 返回access_token
        """
        try:
            url = f"{self.host}/app/installations/{bot_installer_id}/access_tokens"
            headers = {
                "Authorization": f"Bearer {jwt_token}"
            }
            response = request(method="POST", url=url, headers=headers)
            access_token = response.json().get("token", "")
            return access_token
        except Exception as e:
            raise e
