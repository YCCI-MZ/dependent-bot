import json

from requests import request
import requests


class ProjectApi:
    def __init__(self, host, access_token=None):
        self.host = host
        self.headers = {
            "Content-Type": "application/json",
        }
        if access_token:
            self.headers["Authorization"] = f"Bearer {access_token}"

    def get_repo_detail(self, user_name, repo_name):
        try:
            url = f"{self.host}/api/{user_name}/{repo_name}/detail.json"
            print(url)
            response = request(method="GET", url=url, headers={
                "Content-Type": "application/json",
            })
            if response.status_code == 200:
                return json.loads(response.text)
        except Exception as e:
            raise e

    def get_repo_files(self, user_name, repo_name):
        try:
            url = f"{self.host}/api/{user_name}/{repo_name}/files.json"
            print(url)
            response = request(method="GET", url=url, headers={
                "Content-Type": "application/json",
            })
            if response.status_code == 200:
                return json.loads(response.text)
        except Exception as e:
            raise e

    def get_repo_file(self, user_name, repo_name, file_path):
        try:
            url = f"{self.host}/api/{user_name}/{repo_name}/sub_entries.json?filepath={file_path}"
            print(url)
            response = request(method="GET", url=url, headers={
                "Content-Type": "application/json",
            })
            if response.status_code == 200:
                return json.loads(response.text)
        except Exception as e:
            raise e

    def download_file_from_gitlink(self, user_name, repo_name, src_file_path, dst_file_path):
        try:
            url = f"{self.host}/api/{user_name}/{repo_name}/sub_entries.json?filepath={src_file_path}"
            print(url)
            response = request(method="GET", url=url, headers={
                "Content-Type": "application/json",
            })
            if response.status_code == 200:
                # 解析响应的 JSON 数据
                content = response.json()['entries']
                
                if "xml" in src_file_path:
                    # 获取文件内容
                    file_content = content['content']
                    # 写入文件到本地
                    with open(dst_file_path, 'wb') as f:
                        f.write(file_content.encode('utf-8'))

                elif "jar" in src_file_path:
                    download_url = content['download_url']
                    print(download_url)
                    res = requests.get(download_url)
                    if res.status_code == 200:
                        with open(dst_file_path, 'wb') as f:  # 以二进制模式打开文件
                            # print(res.content)
                            f.write(res.content)
        except Exception as e:
            raise e
        
